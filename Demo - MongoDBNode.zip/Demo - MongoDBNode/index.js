const { MongoClient } = require("mongodb");

const uri = "mongodb://admin:adminpassword@localhost:27017";
const client = new MongoClient(uri);

async function main() {
  try {
    await client.connect();
    console.log("✅ Connecté à MongoDB");

    const db = client.db("mydb");
    const users = db.collection("users");

    // Insertion
    const result = await users.insertOne({
      name: "Denis",
      role: "Consultant",
      createdAt: new Date(),
    });

    console.log("📝 Utilisateur inséré :", result.insertedId);

    // Lecture
    const allUsers = await users.find().toArray();
    console.log("📋 Utilisateurs :", allUsers);
  } catch (err) {
    console.error("❌ Erreur MongoDB", err);
  } finally {
    await client.close();
  }
}

main();
